addpath(genpath('../..'))
% mroptimumbartstatup
addpath(genpath(pwd))

PT='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/';
thefile=fullfile(PT,'meas_MID00024_FID188178_Multislice.dat');
S=CLOUDMRRD(thefile);

thenoise=fullfile(PT,'meas_MID00027_FID188181_Multislice_no_RF.dat');
N=CLOUDMRRD(thenoise);

KSN=CLOUDMRSpreadthenoiseinto2DKSpace(N,1);

   AC=24;
K=S.getKSpaceImageSlice('avg',1,1,1);

o=CLOUDMRgetOptions('msensebartsense');
o.AccelerationF=1;  
o.AccelerationP=4;


L=undersamplemSense2D(K,o.AccelerationF,o.AccelerationP,AC);
P=CLOUDMR2DACMmSENSE(L);
P.setConf(o);
P.Autocalibration=AC;
P.setSourceCoilSensitivityMap(L);
M=P.getImage();
sens=P.getSensitivityMatrix();
P.setNoiseKSpace(KSN);

SNR=P.getSNR();
imshow(abs(SNR),[]);


o=CLOUDMRgetOptions('espirits');
o.AccelerationF=1;
o.AccelerationP=2;
P2=CLOUDMR2DACMEspirit(L);
P2.setConf(o);
P2.Autocalibration=AC;
P2.setSourceCoilSensitivityMap(L);
M2=P2.getImage();
sens2=P2.getSensitivityMatrix();
P2.setNoiseKSpace(KSN)
