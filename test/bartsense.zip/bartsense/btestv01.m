addpath(genpath('../..'))
mroptimumbartstatup
addpath(genpath(pwd))

PT='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA';
thefile=fullfile(PT,'meas_MID00036_FID188190_Multislice_100_REPLICAS.dat');
A=CLOUDMRRD(thefile);


%MR
S1=CLOUDMR2DMR();
S2=CLOUDMR2DMR();
S4=CLOUDMR2DMR();
S8=CLOUDMR2DMR();

%recon
for r=1:100
K=A.getKSpaceImageSlice(1,1,r,1);    
BARTK(:,:,1,:)=K;
senseK2(:,:,1,:)=undersamplemSense2D(K,1,2,24);

senseK4(:,:,1,:)=undersamplemSense2D(K,1,4,24);
senseK8(:,:,1,:)=undersamplemSense2D(K,1,8,24);



[calib emaps] = bart('ecalib  ', BARTK); %sense
sens = bart('slice 4 0', calib);
sens_maps = squeeze(sens);
reco = bart('pics', BARTK, sens);
S1.add2DImage(squeeze(reco));


[calib emaps] = bart('ecalib  ', senseK2); %sense
sens = bart('slice 4 0', calib);
sens_maps = squeeze(sens);
reco = bart('pics', senseK2, sens);
S2.add2DImage(squeeze(reco));


[calib emaps] = bart('ecalib  ', senseK4); %sense
sens = bart('slice 4 0', calib);
sens_maps = squeeze(sens);
reco = bart('pics', senseK4, sens);
S4.add2DImage(squeeze(reco));



[calib emaps] = bart('ecalib  ', senseK8); %sense
sens = bart('slice 4 0', calib);
sens_maps = squeeze(sens);
reco = bart('pics', senseK8, sens);

S8.add2DImage(squeeze(reco));
end
