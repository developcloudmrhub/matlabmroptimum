addpath(genpath('../..'))
% mroptimumbartstatup
addpath(genpath(pwd))

PT='/data/test/MROPTIMUM/ARTICLEDATA/INVIVIODATA/Carlotta/Proton/';
thefile=fullfile(PT,'meas_MID95_gre_5deg_1H_TxRef250_TA_5slices_rep1_FID89806.dat');
S=CLOUDMRRD(thefile);

thenoise=fullfile(PT,'thenoise=meas_MID94_gre_5deg_1H_noise_FID89805.dat');
N=CLOUDMRRD(thenoise);

K=S.getKSpaceImageSlice('avg',1,1,1);
L=undersamplemSense2D(K,2,2,24);

o=CLOUDMRgetOptions('msensebartsense');
o.AccelerationF=2;
P=CLOUDMR2DACMmSENSE(L);
P.setConf(o);
P.Autocalibration=24;
P.setSourceCoilSensitivityMap(L);
M=P.getImage();
sens=P.getSensitivityMatrix();

AC=32
o=CLOUDMRgetOptions('espirits');
L=undersamplemSense2D(K,1,2,AC);
o.AccelerationF=1;
P2=CLOUDMR2DACMEspirit(L);
P2.setConf(o);
P2.Autocalibration=AC;
P2.setSourceCoilSensitivityMap(L);
M2=P2.getImage();
sens2=P2.getSensitivityMatrix();
