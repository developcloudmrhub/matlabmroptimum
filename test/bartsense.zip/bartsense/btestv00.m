addpath(genpath('../..'))
mroptimumbartstatup
addpath(genpath(pwd))

PT='/data/test/MROPTIMUM/ARTICLEDATA/INVIVIODATA/Carlotta/Proton/';
thefile=fullfile(PT,'meas_MID95_gre_5deg_1H_TxRef250_TA_5slices_rep1_FID89806.dat');
A=CLOUDMRRD(thefile);




K=A.getKSpaceImageSlice(1,1,1,1);
BARTK(:,:,1,:)=K;
%Dimension Usage
% 0 readout
% 1 phase-encoding dimension 1
% 2 phase-encoding dimension 2
% 3 receive channels
% 4 ESPIRiT maps



%reconstruction fully sampled


%-i sta per inversa 6 e' 2^1+2^2 (le posizioni) bitmask
zf_coils = bart('fft -i 3', BARTK);
%8 sta 2^3 (le posizioni) dei coil
zf_rss = bart('rss 8', zf_coils);

figure;
imshow(abs(squeeze(zf_rss)), []);
title('first test with bart')







%msense mimic with 0 padding
senseK2(:,:,1,:)=undersamplemSense2D(K,2,2,24);



zf_coils = bart('fft -i 3', senseK2);
zf_rss = bart('rss 8', zf_coils);

ksp_rss = squeeze(bart('rss 8', senseK2));
zf_coils = squeeze(zf_coils);
zf_rss = squeeze(zf_rss);
figure,subplot(1,2,1), imshow(abs(ksp_rss).^0.125, []); title('k-space')
subplot(1,2,2), imshow(abs(zf_rss), []); title('SENSE 2x zero-filled recon')


% calmat = bart('calmat -r 20 -k 4', senseK2);
% [U SV VH] = bart('svd', calmat);
% 
% figure, plot(SV);
% title('Singular Values of the Calibration Matrix');

[calib emaps] = bart('ecalib -r 20 ', senseK2); 

%[calib emaps] = bart('ecalib  ', senseK2); %sense
sens = bart('slice 4 0', calib);


sens_maps = squeeze(sens);

figure,
subplot(121), imshow3(abs(sens_maps), [],[2,4]);
title('Magnitude ESPIRiT 1st Set of Maps')
subplot(122), imshow3(angle(sens_maps),[],[2,4])
title('Phase ESPIRiT 1st Set of Maps')


emaps = squeeze(emaps);
figure, imshow3(emaps, [], [1, 2]);
title('First Two Eigenvalue Maps')


reco = bart('pics', senseK2, sens);
sense_recon = squeeze(reco);
figure, imshow(abs(sense_recon), []); title('ESPIRiT Reconstruction')




% full = BARTK;
% proj = bart('pocsense -r 0. -i 4', full, sens);
% % Compute error and transform it into image domain and combine into a single map.
% errimgs = bart('fft -i 3', (full - proj));
% errsos_espirit = bart('rss 8', errimgs);
% %
% % For comparison: compute sensitivities directly from the center.
% %sens_direct = bart('caldir 20', senseK2);
% sens_direct = bart('fft 3', senseK2);
% % Compute error map.
% proj = bart('pocsense -r 0. -i 1', full, sens_direct);
% errimgs = bart('fft -i 3', (full - proj));
% errsos_direct = bart('rss 8', errimgs);
% errsos_espirit = squeeze(errsos_espirit);
% errsos_direct = squeeze(errsos_direct);
% figure,
% imshow(abs([errsos_direct errsos_espirit]), []); title('Projection Error (direct calibration vs ESPIRiT)');










D=CLOUDMR2DACMWithSensitivity(squeeze(senseK2));
D.setSourceCoilSensitivityMap(squeeze(senseK2));
D.setSensitivityCalculationMethod('simplesense')
S=D.getSensitivityMatrix();
sensebart(:,:,1,:)=S; 

reco = bart('pics', senseK2,sensebart);
sense_recon2 = squeeze(reco);
figure, imshow(abs(sense_recon2), []); title('simples sense Reconstruction through bart')

figure, imshow(abs(sense_recon2-sense_recon), []); title('difeerence reconstructed image with Sensitivity from inner and espirit')


