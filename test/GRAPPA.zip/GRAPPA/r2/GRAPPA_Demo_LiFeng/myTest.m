
addpath(genpath('/data/project/mroptimum/MATLABCODE/'))
mroptimumbartstatup
%fullkaspace data
load('SS.mat')

%undersample and shrink image
[L, S]=undersampleSense2D(K,1,2);



%for the sensitivity

res = crop(K,24,24,16);
krecon=permute(grappa4x3(permute(S,[2 1 3]),res,2,1),[2, 1, 3]);

recon=sos(MRifft(krecon,[1 2]),3);

subplot(121)
imshow(recon,[])
title('ACL flag true')


krecon=permute(grappa4x3(permute(S,[2 1 3]),res,2,0),[2, 1, 3]);
recon0=sos(MRifft(krecon,[1 2]),3);
subplot(122)
imshow(recon0,[])
title('ACL flag false')
