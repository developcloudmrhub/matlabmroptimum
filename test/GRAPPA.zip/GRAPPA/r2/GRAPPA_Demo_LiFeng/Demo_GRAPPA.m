addpath D:\lab\lifeng\Software\T2MappingFinalUsed\CS_Rawdata_Reconstruction
addpath D:\lab\lifeng\Software\T2MappingFinalUsed
addpath D:\lab\lifeng\Software\RadialCS\utils
addpath D:\lab\lifeng\Software\RadialCS\nufft_files
addpath D:\lab\lifeng\Software\RadialCS\CS_Rawdata_Reconstruction
addpath D:\lab\lifeng\Software\RadialCS
addpath D:\lab\lifeng\Software\RadialCS\CS_Rawdata_Reconstruction
addpath D:\lab\lifeng\Software\imagescn_R2008a
addpath D:\lab\lifeng\Software\3D_Recon_S
clear all
clc
datadir0='D:\lab\lifeng\Data\3D_MSK\'; 
[file,path]=uigetfile([datadir0,'*.dat'],'Select Mat file:');
[image_obj noise_obj phasecor_obj refscan_obj]  = mapVBVD([path file]);
kdata=image_obj();
kref=refscan_obj();
clear image_obj noise_obj phasecor_obj refscan_obj
kdata=permute(squeeze(kdata(:,:,:,:,11)),[3,1,2]);
acs=permute(squeeze(kref(:,:,:,:,11)),[3,1,2]);
[ny,nx,nc]=size(kdata);
acc=2;
sig=zeros(ny/acc,nx,nc);
sig=kdata(2:2:end,:,:);

krecon=grappa4x3(sig,acs,acc,0);
recon=sos(ifft2c_mri(krecon),3);