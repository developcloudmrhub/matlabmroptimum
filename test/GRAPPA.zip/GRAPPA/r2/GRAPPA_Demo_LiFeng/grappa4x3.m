function krecon=grappa4x3(sig,acs,af,flag_acs);

% GRAPPA reconstruction (4x3 kernel) of a 2D image with uniform
% acceleration along the y dimension
%-------------------------------------------------------------------------
%	Input:
%	sig: accelerated acquisition [ny,nx,nc].
%	acs: autocalibration signal  [nyacs,nxacs,nc].
%	af: acceleration factor (integers only).
%   flag_acs: 1, include the acs data into the final reconstruction
%
%	Output:
%	krecon: coil-by-coil k-space recon [ny*af,nx,nc].
%--------------------------------------------------------------------------
% Ricardo Otazo
%

if nargin<4, flag_acs=0;end

[ny,nx,nc]=size(sig);
[nyacs,nxacs,nc]=size(acs);

% fprintf(strcat('\n GRAPPA reconstruction with 4x3 kernel ........................................\n'));
% fprintf(strcat('\n Gradient-encoding data: ',int2str(ny),'x',int2str(nx),'(Ry=',int2str(af),')'));
% fprintf(strcat('\n Autocalibration data: ',int2str(nyacs),'x',int2str(nxacs)));
% fprintf(strcat('\n Number of channels: ',int2str(nc),'\n'));

src=zeros((nyacs-3*af)*(nxacs-2),nc*12);
targ=zeros(af-1,(nyacs-3*af)*(nxacs-2),nc);

src_idx=0;
% fprintf('\n computing weights ...\n');
% collecting source and target data
for xi=2:nxacs-1,
    for yi=1:nyacs-3*af,
        src_idx=src_idx+1;
        % collects a 4x3 block of source points around the target point
        block=[];
        for bxi=-1:1,
            for byi=0:3,
                block=cat(1,block,squeeze(acs(yi+byi*af,xi+bxi,:)));
            end
        end
        src(src_idx,:)=block;
        % target point for these 4x3 points
        for afi=1:af-1,
            targ(afi,src_idx,:)=squeeze(acs(yi+af+afi,xi,:));
        end
    end
end
% weights using pseudoinverse
ws=zeros(af-1,nc*12,nc);
for afi=1:af-1,
    ws(afi,:,:)=inv(src'*src)*src'*squeeze(targ(afi,:,:));
end
% reconstructed k-space matrix
krecon=zeros(ny*af+4*af,nx+2,nc);
% source data in the reconstructed k-space matrix
krecon(2*af+1:af:end-2*af,2:end-1,:)=sig;
% edges of k-space: cyclic
% krecon(1,2:end-1,:)=conj(sig(end-1,end:-1:1,:));
% krecon(af+1,2:end-1,:)=conj(sig(end,end:-1:1,:));
% krecon(ny*af+af+1,2:end-1,:)=conj(sig(2,end:-1:1,:));
% krecon(ny*af+2*af+1,2:end-1,:)=conj(sig(1,end:-1:1,:));
% krecon(2*af+1:af:end-2*af,1,:)=conj(sig(end:-1:1,end,:));
% krecon(2*af+1:af:end-2*af,nx+2,:)=conj(sig(end:-1:1,1,:));

% fprintf('\n computing missing k-space points ...\n');
for xi=2:nx-1,
    for yi=1:af:ny*af,
        src=[];
        for bxi=-1:1,
            for byi=0:3,
                src=cat(1,src,squeeze(krecon(yi+byi*af,xi+bxi,:)));
            end
        end
        % recon=source*weights
        for afi=1:af-1,
            krecon(yi+af+afi,xi,:)=transpose(src)*squeeze(ws(afi,:,:));
        end
    end
end
if flag_acs,
    krecon((ny*af+4*af)/2-nyacs/2+1:(ny*af+4*af)/2+nyacs/2,(nx+2)/2-nxacs/2+1:(nx+2)/2+nxacs/2,:)=acs;
end
% cropping out the good data
if mod(af,2)==1,
    krecon=krecon(2*af+1:ny*af+2*af-1,2:nx+1,:);
else
    krecon=krecon(2*af:ny*af+2*af-1,2:nx+1,:);
end

% fprintf('\n done! ........................................................................\n');