function [KOUT, SHRINK,MASK, info]=undersampleGrappa2D(K,frequencyacceleration,phaseacceleration,autocalibration)
%K is a kspace 2d data (frequency,phase,coil) just alias for msense2d
% phaseacceleration
% set ACS lines for mSense simulation (fully sampled central k-space
% region)

[KOUT, SHRINK,MASK, info]=undersamplemSense2D(K,frequencyacceleration,phaseacceleration,autocalibration);