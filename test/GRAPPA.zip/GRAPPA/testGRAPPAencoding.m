

f=dir('/data/test/MROPTIMUM/ARTICLEDATA/INVIVIODATA/INVIVO/*.dat');
 
A=CLOUDMRRD(fullfile(f(1).folder,f(1).name));

%K=randn(20,20);

K=A.getKSpaceImageSlice(1,1,1,1);

GRAPPAK=undersampleGrappa2D(K,2,24);