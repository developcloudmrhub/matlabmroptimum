
%COILKSPACE=mapvbvd...

%function [coilse_set]=BC(COILKSPACE,BODYCOILKSPACE)

PT='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/';

bc=mapVBVD(fullfile(PT,'meas_MID00025_FID188179_Multislice_bodycoil.dat'),'removeOS');
BC_=permute(bc.image(),[1,3,2,4,5]);
BODYCOILKSPACE=BC_(:,:,:,1,1);


im=mapVBVD(fullfile(PT,'meas_MID00024_FID188178_Multislice.dat'),'removeOS');
IM_=permute(im.image(),[1,3,2,4,5]);
COILKSPACE=IM_(:,:,:,1,1);


normalize_matrix=MRifft(BODYCOILKSPACE,[1,2])*sqrt(size(BODYCOILKSPACE,1)*size(BODYCOILKSPACE,2));

%%% NOTA: NON E' CORRETTO CHIAMARE LE IMMAGINI DEI COIL REFERENCE_IMAGE,
%%% CAMBIAMO IN COIL_IMAGES
reference_image= MRifft(COILKSPACE,[1,2])*sqrt(size(COILKSPACE,1)*size(COILKSPACE,2));

mask_phantom = sqrt(sum(abs(reference_image).^2,3)) > 2e-5;

nchan=size(COILKSPACE,3);
nfreq=size(COILKSPACE,1);
nphase=size(COILKSPACE,2);

SourceCoilSensitivityMapNCoils=size(BODYCOILKSPACE,3);

switch( SourceCoilSensitivityMapNCoils)
    
    %case one coil
    case 1
        coilsens_set = reference_image/repmat(normalize_matrix,[1 1 nchan]);
        %  case two coils
    case 2
        center_phase_1 = angle(normalize_matrix(48,48,1));
        center_phase_2 = angle(normalize_matrix(48,48,2));
        image_1 = normalize_matrix(:,:,1)*exp(-1i*center_phase_1);
        image_2 = normalize_matrix(:,:,2)*exp(-1i*center_phase_2);
%       BCIM=sqrt(abs(normalize_matrix(:,:,1)).^2 + abs(normalize_matrix(:,:,2)).^2);
%       BCIM =abs(image_1 + image_2))/sqrt(2);
        BCIM = abs((image_1 + 1i*image_2))/sqrt(2);

        coilsens_set = reference_image./repmat(abs(BCIM),[1 1 nchan]);
    otherwise
        %in this case 1th kspace of the bodycoil
        coilsens_set = reference_image./repmat(normalize_matrix(:,:,1),[1 1 nchan]);
end
for ichan=1:nchan
    %     PP=prctile(reshape(coilsens_set(:,:,ichan),[],1),99);
    %     coilsens_set(:,:,ichan)=coilsens_set(:,:,ichan)./(ones(size(coilsens_set,1),size(coilsens_set,2)).*PP);
    temp_img = coilsens_set(:,:,ichan);
    coilsens_set(:,:,ichan)=coilsens_set(:,:,ichan)./max(temp_img(mask_phantom));
end

% Compare with other normalization approaches

% SoS of all coils (simple sense in Riccardo's code, I think it's now called internal reference, but we can revise the name)
normalization_mat_sos = sqrt(sum(abs(reference_image).^2,3));
coilsens_set_sos = reference_image./repmat(normalization_mat_sos,[1 1 nchan]);

% First image after SVD (to be added as an option, name to ne decided)
[U,~,~] = svd(reshape(reference_image,[96*96,nchan]),'econ');
svd_coils = reshape(U,[96,96,nchan]);
normalization_mat_svd = svd_coils(:,:,1);
coilsens_set_svd = reference_image./repmat(abs(normalization_mat_svd),[1 1 nchan]);
for ichan=1:nchan
%     PP=prctile(reshape(coilsens_set_svd(:,:,ichan),[],1),99);
%     coilsens_set_svd(:,:,ichan)=coilsens_set_svd(:,:,ichan)./(ones(size(coilsens_set_svd,1),size(coilsens_set_svd,2)).*PP);
    temp_img = coilsens_set_svd(:,:,ichan);
    coilsens_set_svd(:,:,ichan)=coilsens_set_svd(:,:,ichan)./max(temp_img(mask_phantom));
end

% PLOT COMPARISON

figure
set(gcf,'name','NORMALIZATION MATRICES')
subplot(3,3,1)
imagesc(abs(BCIM))
title('BODY COIL IMAGE')
colorbar
axis square
subplot(3,3,2)
imagesc(abs(normalization_mat_sos))
title('SoS IMAGE')
colorbar
axis square
subplot(3,3,3)
imagesc(abs(normalization_mat_svd))
title('SVD IMAGE')
colorbar
axis square

subplot(3,3,4)
plot(abs(BCIM(48,:)),'LineWidth',3)
title('BODY COIL IMAGE')
subplot(3,3,5)
plot(abs(normalization_mat_sos(48,:)),'LineWidth',3)
title('SoS IMAGE')
subplot(3,3,6)
plot(abs(normalization_mat_svd(48,:)),'LineWidth',3)
title('SVD IMAGE')

subplot(3,3,7)
plot(abs(BCIM(:,48)),'r','LineWidth',3)
title('BODY COIL IMAGE')
subplot(3,3,8)
plot(abs(normalization_mat_sos(:,48)),'r','LineWidth',3)
title('SoS IMAGE')
subplot(3,3,9)
plot(abs(normalization_mat_svd(:,48)),'r','LineWidth',3)
title('SVD IMAGE')


figure;
set(gcf,'name','BODY COIL NORMALIZATION')
for ichan = 1:nchan
    subplot(4,4,ichan)
    imagesc(abs(coilsens_set(:,:,ichan)).*mask_phantom,[0 0.65]);
    axis square
end
figure;
set(gcf,'name','SOS OF ALL COILS NORMALIZATION')
for ichan = 1:nchan
    subplot(4,4,ichan)
    imagesc(abs(coilsens_set_sos(:,:,ichan)).*mask_phantom,[0 0.65]);
    axis square
end
figure;
set(gcf,'name','FIRST COMPONENT OF SVD NORMALIZATION')
for ichan = 1:nchan
    subplot(4,4,ichan)
    imagesc(abs(coilsens_set_svd(:,:,ichan)).*mask_phantom,[0 0.65]);
    axis square
end

figure;
set(gcf,'name','COMPARE METHODS')
subplot(4,3,1)
imagesc(abs(coilsens_set(:,:,1)).*mask_phantom);
title('BC (Coil 1)');
axis square
colorbar
subplot(4,3,2)
imagesc(abs(coilsens_set_sos(:,:,1)).*mask_phantom);
title('SoS (Coil 1)');
axis square
colorbar
subplot(4,3,3)
imagesc(abs(coilsens_set_svd(:,:,1)).*mask_phantom);
title('SVD (Coil 1)');
axis square
colorbar

subplot(4,3,4)
imagesc(abs(coilsens_set(:,:,5)).*mask_phantom);
title('BC (Coil 5)');
axis square
colorbar
subplot(4,3,5)
imagesc(abs(coilsens_set_sos(:,:,5)).*mask_phantom);
title('SoS (Coil 5)');
axis square
colorbar
subplot(4,3,6)
imagesc(abs(coilsens_set_svd(:,:,5)).*mask_phantom);
title('SVD (Coil 5)');
axis square
colorbar

subplot(4,3,7)
imagesc(abs(coilsens_set(:,:,10)).*mask_phantom);
title('BC (Coil 10)');
axis square
colorbar
subplot(4,3,8)
imagesc(abs(coilsens_set_sos(:,:,10)).*mask_phantom);
title('SoS (Coil 10)');
axis square
colorbar
subplot(4,3,9)
imagesc(abs(coilsens_set_svd(:,:,10)).*mask_phantom);
title('SVD (Coil 10)');
axis square
colorbar

subplot(4,3,10)
imagesc(abs(coilsens_set(:,:,16)).*mask_phantom);
title('BC (Coil 16)');
axis square
colorbar
subplot(4,3,11)
imagesc(abs(coilsens_set_sos(:,:,16)).*mask_phantom);
title('SoS (Coil 16)');
axis square
colorbar
subplot(4,3,12)
imagesc(abs(coilsens_set_svd(:,:,16)).*mask_phantom);
title('SVD (Coil 16)');
axis square
colorbar






