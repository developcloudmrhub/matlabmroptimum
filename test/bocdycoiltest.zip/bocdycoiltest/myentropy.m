function[o]=myentropy(im,arr)


p=hist(im(:),arr);

o=-sum(p.*log2(p));