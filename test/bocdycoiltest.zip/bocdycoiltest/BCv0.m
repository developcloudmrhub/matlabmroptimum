
%COILKSPACE=mapvbvd...

%function [coilse_set]=BC(COILKSPACE,BODYCOILKSPACE)

PT='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/';

bc=mapVBVD(fullfile(PT,'meas_MID00025_FID188179_Multislice_bodycoil.dat'),'removeOS');
BC_=permute(bc.image(),[1,3,2,4,5]);
BODYCOILKSPACE=BC_(:,:,:,1,1);


im=mapVBVD(fullfile(PT,'meas_MID00024_FID188178_Multislice.dat'),'removeOS');
IM_=permute(im.image(),[1,3,2,4,5]);
COILKSPACE=IM_(:,:,:,1,1);



normalize_matrix=MRifft(BODYCOILKSPACE,[1,2])*sqrt(size(BODYCOILKSPACE,1)*size(BODYCOILKSPACE,2));

reference_image= MRifft(COILKSPACE,[1,2])*sqrt(size(COILKSPACE,1)*size(COILKSPACE,2));

nchan=size(COILKSPACE,3);

SourceCoilSensitivityMapNCoils=size(BODYCOILKSPACE,3);

switch( SourceCoilSensitivityMapNCoils)
    
    %case one coil
    case 1
        coilsens_set = reference_image/repmat(normalize_matrix,[1 1 nchan]);
        %  case two coils
    case 2
        BCIM=(normalize_matrix(:,:,1)+1i*(normalize_matrix(:,:,2)))/sqrt(2);
        coilsens_set = reference_image./repmat(abs(BCIM),[1 1 nchan]);
    otherwise
        %in this case 1th kspace of the bodycoil
        coilsens_set = reference_image./repmat(normalize_matrix(:,:,1),[1 1 nchan]);
end


for nc=1:nchan
    PP=prctile(reshape(coilsens_set(:,:,nc),[],1),99);
    coilsens_set(:,:,nc)=coilsens_set(:,:,nc)./(ones(size(coilsens_set,1),size(coilsens_set,2)).*PP);
    
end
