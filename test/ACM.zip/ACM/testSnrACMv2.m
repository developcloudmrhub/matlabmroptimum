function[]=testSnrACMv2(signalFilename,noiseFilename,OUTDIR,o)

%% dat filename signal and noise, maindirectory to save, option structure (required)


%% reading and gather the data

% dname= fullfile(DAT(1).folder,DAT(1).name);
% ename= fullfile(DAT(1).folder,NOISE(1).name);






%noise is in a seprate file
KN=CLOUDMRRD();
KN.setFilename(noiseFilename);



KS=CLOUDMRRD();
KS.setFilename(signalFilename);










SS=size(KS.getKSpaceImageSlice('avg',1,1,1));

KN.getKSpaceImageSlice(1,1,1,1);
  
rep=KS.getNumberRepetition();
SL=KS.getNumberImageSlices();

SNR=NaN(SS(1),SS(2),SS(3),rep);

if (strcmpi(o.Type,'sense'))
    G=NaN(SS(1),SS(2),SS(3),rep);
end



    for r=1:rep
        display(r);
        
        for sl=1:SL
            
            ks= KS.getKSpaceImageSlice('avg',1,r,sl);
            kn=KN.getKSpaceImageSlice(1,1,1,sl);
            if (strcmpi(o.Type,'sense'))
            [SNR(:,:,sl,r) , ~, G(:,:,sl,r)]=debug_SNRmat2(ks,kn,o);
            else
            [SNR(:,:,sl,r)]=debug_SNRmat2(ks,kn,o);
            end            
        end
        
        
    end
    mkdir(OUTDIR);


if (strcmpi(o.Type,'sense'))
    save(OUTDIR,'SNR','o','G');
else
    save(OUTDIR,'SNR','o');
end


end
