%i'll put images
o.FlipAngleMap="no";
o.NoiseFileType='noiseFile';

o.SensitivityCalculationMethod='simplesense';
o.SourceCoilSensitivityMap='self';
o.SaveCoils=false;
o.NBW=0;
o.SourceCoilSensitivityMapSmooth=false;
o.Name='ACMRloop_B1_2_simp';
o.type='b1';
o.Type='b1';

OUTDIR=fullfile(pwd,o.Name);
mkdir(OUTDIR);





s='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat';
n='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat';
testSnrACMv2(s,n,OUTDIR,o)