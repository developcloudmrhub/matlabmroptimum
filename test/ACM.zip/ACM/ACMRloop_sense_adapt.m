o.FlipAngleMap="no";
o.NoiseFileType='noiseFile';

o.SensitivityCalculationMethod='adaptive';
o.SourceCoilSensitivityMap='self';
o.SaveCoils=false;
o.NBW=0;
o.Name='ACM_SENSE_adaptive2d_2';
o.SourceCoilSensitivityMapSmooth=false;


o.type='sense';
o.Type='sense';
o.AccelerationF=1;
o.AccelerationP=2;
o.GFactorMask='no';


OUTDIR=fullfile(pwd,o.Name);
mkdir(OUTDIR);


 s='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; n='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; testSnrACMv2(s,n,OUTDIR,o)

o.type='sense';
o.Type='sense';
o.AccelerationF=1;
o.AccelerationP=4;
o.GFactorMask='no';
o.Name='ACM_SENSE_adaptive2d_4';


OUTDIR=fullfile(pwd,o.Name);
mkdir(OUTDIR);


 s='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; n='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; testSnrACMv2(s,n,OUTDIR,o)


o.type='sense';
o.Type='sense';
o.AccelerationF=1;
o.AccelerationP=8;
o.GFactorMask='no';
o.Name='ACM_SENSE_adaptive2d_8';


OUTDIR=fullfile(pwd,o.Name);
mkdir(OUTDIR);


 s='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; n='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; testSnrACMv2(s,n,OUTDIR,o)



o.type='sense';
o.Type='sense';
o.AccelerationF=1;
o.AccelerationP=16;
o.GFactorMask='no';
o.Name='ACM_SENSE_adaptive2d_16';


OUTDIR=fullfile(pwd,o.Name);
mkdir(OUTDIR);


 s='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; n='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; testSnrACMv2(s,n,OUTDIR,o)




o.type='sense';
o.Type='sense';
o.AccelerationF=1;
o.AccelerationP=1;
o.GFactorMask='no';
o.Name='ACM_SENSE_adaptive2d_1';


OUTDIR=fullfile(pwd,o.Name);
mkdir(OUTDIR);


 s='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; n='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat'; testSnrACMv2(s,n,OUTDIR,o)
