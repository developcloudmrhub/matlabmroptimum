function [SNR,L,GF]= debug_SNRmat2(KSS,KSN,o)
%create the snr matrix (signal file,noisefile,jop is the position of thejson for options,m is the method,json output,l is the json log file)



TMP=pwd;




%    switch lower(m)
switch lower(o.Type)
    case 'rss'
        L=CLOUDMR2DACMRSS();
    case 'sense'
        L=CLOUDMR2DACMSENSE();
        o.AccelerationF=o.AccelerationF; % this must be set if i change the API
        o.AccelerationP=o.AccelerationP;         % this must be set if i change the API
    case 'b1'
        L=CLOUDMR2DACMB1();
    otherwise
        L=CLOUDMR2DACM();
end

L.logIT('start calculation','start');



%istantiate noise data the data is able to understand which kind of data is
%(ismrmrd and siemens by now)
KN=CLOUDMRRD();

%set the noise data if the noise is set o self it will be set by the image
%sequence


%caluclate set the noise statistics
L.setNoiseKSpace(KSN);
L.logIT('set noise ','ok');
noisecoef=L.getNoiseCoefficients();
noisecov=L.getNoiseCovariance();


SL=1;






if (strcmpi(o.Type,'sense') || strcmpi(o.Type,'b1'))
    
    
    switch(o.SensitivityCalculationMethod)
        case {'simplesense', 'adaptive'}
            L.setSourceCoilSensitivityMap(KSS);
        case {'BodyCoil'}
            
            
            BC=CLOUDMRRD();
            BC.setFilename(o.bc);
            
            L.setSourceCoilSensitivityMap(BC.getKSpaceImageSlice('avg',1,1,1));
            
            
    end
    
    
    
    
    %         o=rmfield (o,'SourceCoilSensitivityMap');
    
    
end






%set the options
try
    L.setConf(o);
catch
    L.logIT(['problem with the conf' jop ],'ko');
end







L.setSignalKSpace(KSS);

    
        SNR=L.getSNR();
        if (strcmpi(o.Type,'sense'))
            GF=L.getGFactor();
            MA=L.getMask();
        else
            GF=[];
        end
        
        
    L.addToExporter('image2D','SNR Image',SNR);
    
    if (strcmpi(o.Type,'sense'))
        L.addToExporter('image2D','GFactor',GF);
        L.addToExporter('image2D','GFactor Mask',MA);
    end

end

