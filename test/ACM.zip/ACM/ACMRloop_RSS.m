%i'll put images
o.Type='RSS';
o.UseCovarianceMatrix=false;
o.FlipAngleMap="no";
o.NBW=0;
o.type='RSS';
o.NR=0;
o.NoiseFileType='noiseFile';
o.Name='ACM_RSS';


OUTDIR=fullfile(pwd,o.Name);
mkdir(OUTDIR);





s='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat';
n='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA/meas_MID00024_FID188178_Multislice.dat';
testSnrACMv2(s,n,OUTDIR,o)