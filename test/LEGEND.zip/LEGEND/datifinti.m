

function[]=datifinti(a);



mi=min(a);

ma=max(a);


T = (ma - mi) / 5;


EXP=esponenteinbasedi(mi + (T * 5),10);


fprintf(1,['(' num2str(mi) ') - ' num2str(EXP) ' - (' num2str(ma) ')\n\n']);


for k =[5:-1:0]
      
    
    R = mi + (T * k);
    
    fprintf(1,[num2str(R) ', ']);
    if (k == 5)
        fprintf(2,[num2str(R/EXP) '^' num2str(log10(EXP))]);
   
        
    else
        fprintf(1,num2str(R/EXP));
        
    end
    fprintf(1,'\n');
end