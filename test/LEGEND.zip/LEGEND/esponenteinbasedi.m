function[out]=esponenteinbasedi(number,base)



out=10^(floor(log10(number)));