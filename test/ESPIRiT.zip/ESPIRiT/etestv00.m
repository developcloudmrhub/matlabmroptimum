

%this test check the differences on a b1 reconstruction using simple sense
%or espirit

PT='/data/test/MROPTIMUM/ARTICLEDATA/INVIVIODATA/Carlotta/Proton/';
thefile=fullfile(PT,'meas_MID95_gre_5deg_1H_TxRef250_TA_5slices_rep1_FID89806.dat');
S=CLOUDMRRD(thefile);

thenoise=fullfile(PT,'meas_MID94_gre_5deg_1H_noise_FID89805.dat');
N=CLOUDMRRD(thenoise);

K=S.getKSpaceImageSlice('avg',1,1,1);
%L=undersamplemSense2D(K,2,2,24);

o=CLOUDMRgetOptions('b1simplesense');

P=CLOUDMR2DACMB1(K)
P.setNoiseKSpace(N.getKSpaceImageSlice(0,1,1,1));
P.setConf(o);
P.setSourceCoilSensitivityMap(K);

sens=P.getSensitivityMatrix();
M=P.getImage();




o2=CLOUDMRgetOptions('b1espirit');

P2=CLOUDMR2DACMB1(K);
P2.setNoiseKSpace(N.getKSpaceImageSlice(0,1,1,1));
P2.setConf(o2);
P2.setSourceCoilSensitivityMap(K);

sens=P.getSensitivityMatrix();

M2=P2.getImage();

figure;
subplot(1,3,1);imshow(M,[]); colorbar;title('simplesense')
subplot(1,3,2);imshow(M2,[]); colorbar;title('espirit')

subplot(1,3,3);imshow((M-M2)./M,[]); colorbar;title('sub simple-espirit')

