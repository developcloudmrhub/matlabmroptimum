addpath(genpath('../..'))
mroptimumbartstatup
addpath(genpath(pwd))

PT='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA';
thefile=fullfile(PT,'meas_MID00036_FID188190_Multislice_100_REPLICAS.dat');
A=CLOUDMRRD(thefile);
thenoise=fullfile(PT,'meas_MID00027_FID188181_Multislice_no_RF.dat');
N=CLOUDMRRD(thenoise);


KN=CLOUDMRSpreadthenoiseinto2DKSpace(N,true);

%b1espirit','rssbart','msensebartsense','msenseespirits','rss','b1simplesense','b1bc'


%MR




ACC= [1 2 4];
AC=24;
for t=(1:3)
    os2=CLOUDMRgetOptions('msensebartsense');
    os2.AccelerationF=1;
    os2.AccelerationP=ACC(t);
    os2.Autocalibration=AC;
    
    SI{t}=CLOUDMR2DACMEspirit();
    SI{t}.setConf(os2);
    SI{t}.setNoiseKSpace(KN);
    
    MRS{t}=CLOUDMR2DMR();
    
    
    o2=CLOUDMRgetOptions('espirits');
 
    o2.AccelerationF=1;
    o2.AccelerationP=ACC(t);
    o2.Autocalibration=AC;
    EI{t}=CLOUDMR2DACMEspirit();
    EI{t}.setNoiseKSpace(KN);
    EI{t}.setConf(o2);
    
    MRE{t}=CLOUDMR2DMR();
    
end





for r=1:100
    K=A.getKSpaceImageSlice(1,1,r,1);
    
    
    for t=(1:3)
         L=undersamplemSense2D(K,1,ACC(t),AC);
            SI{t}.setSignalKSpace(L);
            SI{t}.setSourceCoilSensitivityMap(L);
            MRS{t}.add2DImage(SI{t}.getImage());
            
            EI{t}.setSignalKSpace(L);
            EI{t}.setSourceCoilSensitivityMap(L);
            MRE{t}.add2DImage(EI{t}.getImage());
            
    end
    
    
end