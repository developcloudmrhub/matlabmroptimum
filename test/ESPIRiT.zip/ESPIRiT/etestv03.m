addpath(genpath('../..'))
mroptimumbartstatup
addpath(genpath(pwd))

PT='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA';
thefile=fullfile(PT,'meas_MID00036_FID188190_Multislice_100_REPLICAS.dat');
A=CLOUDMRRD(thefile);
thenoise=fullfile(PT,'meas_MID00027_FID188181_Multislice_no_RF.dat');
N=CLOUDMRRD(thenoise);


KN=CLOUDMRSpreadthenoiseinto2DKSpace(N,true);

%b1espirit','rssbart','msensebartsense','msenseespirits','rss','b1simplesense','b1bc'


%MR
R=CLOUDMR2DMR();
%inzializzazione delle classi
or=CLOUDMRgetOptions('rssbart');
RI=CLOUDMR2DACMRSSBART();


MRB1=CLOUDMR2DMR();
ob=CLOUDMRgetOptions('b1espirit');
B1I=CLOUDMR2DACMB1();


MRB1B=CLOUDMR2DMR();
ob=CLOUDMRgetOptions('b1espirit');
B1BI=CLOUDMR2DACMB1BART();



% 
% 
% 
% 
% 
% P=CLOUDMR2DACMmSENSE(L);
% 
% P.setConf(o);
% P.Autocalibration=24;
% P.setSourceCoilSensitivityMap(L);
% M=P.getImage();
% sens=P.getSensitivityMatrix();
% 
% 
% B1=CLOUDMR2DMR();
% S1=CLOUDMR2DMR();
% S2=CLOUDMR2DMR();
% S4=CLOUDMR2DMR();
% 
% E1=CLOUDMR2DMR();
% E2=CLOUDMR2DMR();
% E4=CLOUDMR2DMR();
% 
% 
% 
% 
% %inzializzazione delle classi
% os2=CLOUDMRgetOptions('msensebartsense');
% os2.AccelerationF=2;
% P=CLOUDMR2DACMmSENSE(L);
% P.setConf(o);
% P.Autocalibration=24;
% P.setSourceCoilSensitivityMap(L);
% M=P.getImage();
% sens=P.getSensitivityMatrix();
% 
% AC=32;
% o=CLOUDMRgetOptions('espirits');
% L=undersamplemSense2D(K,1,2,AC);
% o.AccelerationF=1;
% P2=CLOUDMR2DACMEspirit(L);
% P2.setConf(o);
% P2.Autocalibration=AC;
% P2.setSourceCoilSensitivityMap(L);
% M2=P2.getImage();
% sens2=P2.getSensitivityMatrix();
% 
% 
% 
% 
% 
% 
% %recon
% 
% KN=N.getKSpaceImageSlice(0,1,1,1);


B1I.setNoiseKSpace(KN);


B1I.setConf(ob);

B1BI.setNoiseKSpace(KN);
B1BI.setConf(ob);


for r=1:100
K=A.getKSpaceImageSlice(1,1,r,1);    
%K2=undersamplemSense2D(K,2,2,24);


RI.setSignalKSpace(K);

R.add2DImage(RI.getImage());



B1I.setSignalKSpace(K);

B1I.setSourceCoilSensitivityMap(K);

M2=B1I.getImage();


MRB1.add2DImage(M2);



B1BI.setSignalKSpace(K);

B1BI.setSourceCoilSensitivityMap(K);

M2B=B1BI.getImage();


MRB1B.add2DImage(M2B);




end