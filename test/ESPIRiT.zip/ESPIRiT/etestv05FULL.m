addpath(genpath('../..'))
mroptimumbartstatup
addpath(genpath(pwd))

PT='/data/MYDATA/TestSNR_15Apr2019_multislice/RAWDATA';
thefile=fullfile(PT,'meas_MID00036_FID188190_Multislice_100_REPLICAS.dat');
A=CLOUDMRRD(thefile);
thenoise=fullfile(PT,'meas_MID00027_FID188181_Multislice_no_RF.dat');
N=CLOUDMRRD(thenoise);


KN=CLOUDMRSpreadthenoiseinto2DKSpace(N,true);

%b1espirit','rssbart','msensebartsense','msenseespirits','rss','b1simplesense','b1bc'
%thats the real super script for MR

%MR
ACC= [1 2 4];
AC=24;
for t=(1:3)
    for sl=1:5
        os2=CLOUDMRgetOptions('msensebartsense');
        os2.AccelerationF=1;
        os2.AccelerationP=ACC(t);
        os2.Autocalibration=AC;
        
        SI{t,sl}=CLOUDMR2DACMEspirit();
        SI{t,sl}.setConf(os2);
        SI{t,sl}.setNoiseKSpace(KN);
        
        MRS{t,sl}=CLOUDMR2DMR();
        
        
        o2=CLOUDMRgetOptions('espirits');
        
        o2.AccelerationF=1;
        o2.AccelerationP=ACC(t);
        o2.Autocalibration=AC;
        EI{t,sl}=CLOUDMR2DACMEspirit();
        EI{t,sl}.setNoiseKSpace(KN);
        EI{t,sl}.setConf(o2);
        
        MRE{t,sl}=CLOUDMR2DMR();
    end
end

for sl=1:5
    %MR
    MRR{sl}=CLOUDMR2DMR();
    %inzializzazione delle classi
    or=CLOUDMRgetOptions('rssbart');
    RI{sl}=CLOUDMR2DACMRSSBART();
    
    
    MRB1{sl}=CLOUDMR2DMR();
    ob=CLOUDMRgetOptions('b1espirit');
    B1I{sl}=CLOUDMR2DACMB1();
    
    B1I{sl}.setNoiseKSpace(KN);
    B1I{sl}.setConf(ob);
    
    
    MRB1B{sl}=CLOUDMR2DMR();
    ob=CLOUDMRgetOptions('b1espirit');
    B1BI{sl}=CLOUDMR2DACMB1BART();
    
    B1BI{sl}.setNoiseKSpace(KN);
    B1BI{sl}.setConf(ob);
    
    
end



for r=1:100
    for sl=1:5
        
        K=A.getKSpaceImageSlice(1,1,r,sl);
        
        RI{sl}.setSignalKSpace(K);
        
        MRR{sl}.add2DImage(RI{sl}.getImage());
        
        
        
        B1I{sl}.setSignalKSpace(K);
        
        B1I{sl}.setSourceCoilSensitivityMap(K);
        
        M2=B1I{sl}.getImage();
        
        
        MRB1{sl}.add2DImage(M2);
        
        
        
        B1BI{sl}.setSignalKSpace(K);
        
        B1BI{sl}.setSourceCoilSensitivityMap(K);
        
        M2B=B1BI{sl}.getImage();
        
        
        MRB1B{sl}.add2DImage(M2B);
        
                
        
        for t=(1:3)
            L=undersamplemSense2D(K,sl,ACC(t),AC);
            SI{t,sl}.setSignalKSpace(L);
            SI{t,sl}.setSourceCoilSensitivityMap(L);
            MRS{t,sl}.add2DImage(SI{t,sl}.getImage());
            
            EI{t,sl}.setSignalKSpace(L);
            EI{t,sl}.setSourceCoilSensitivityMap(L);
            MRE{t,sl}.add2DImage(EI{t,sl}.getImage());
            
        end
        
    end
end




