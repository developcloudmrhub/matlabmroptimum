% PT='/data/test/MROPTIMUM/ARTICLEDATA/INVIVIODATA/Carlotta/Proton/';
% thefile=fullfile(PT,'meas_MID95_gre_5deg_1H_TxRef250_TA_5slices_rep1_FID89806.dat');
% S=CLOUDMRRD(thefile);
% 
% thenoise=fullfile(PT,'meas_MID94_gre_5deg_1H_noise_FID89805.dat');
% N=CLOUDMRRD(thenoise);
% 
% K=S.getKSpaceImageSlice('avg',1,1,1);


c=0;
for t=10:4:95
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'testAnimated.gif';

    c=c+1;
    S{c}=espirit_sensitivitymap(K,t,[6 6]);
    imshow3(real(S{c}),[],[1 size(K,3)]);
    title(['LINES ' num2str(t) ' over ' num2str(size(K,1))]);
    frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,256); 
      % Write to the GIF File 
      if c== 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','WriteMode','append'); 
      end 
close(h)      
end
      
    AC=24;
    
L=undersamplemSense2D(K,1,2,AC);

c=0;
for t=10:4:95
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'testAnimatedUndersampled2 2 24.gif';

    c=c+1;
    S{c}=espirit_sensitivitymap(L,t,[6 6]);
    imshow3(real(S{c}),[],[1 size(K,3)]);
    title(['LINES ' num2str(t) ' over ' num2str(size(K,1))]);
    frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,256); 
      % Write to the GIF File 
      if c== 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','WriteMode','append'); 
      end 
close(h)      
end





for t=1:18
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'kernel.gif';

    
  S{t}=espirit_sensitivitymap(K,24,[t t]);
  imshow3(real(S{t}),[],[1 size(K,3)]);
    title(['LINES ' num2str(t) ' over ' num2str(size(K,1))]);
    frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,256); 
      % Write to the GIF File 
      if t== 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','WriteMode','append'); 
      end 
close(h)      
end




for t=1:18
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'kernel1_2_24.gif';

    
  S{t}=espirit_sensitivitymap(L,24,[t t]);
  imshow3(real(S{t}),[],[1 size(K,3)]);
    title(['LINES ' num2str(t) ' over ' num2str(size(K,1))]);
    frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,256); 
      % Write to the GIF File 
      if t== 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','WriteMode','append'); 
      end 
close(h)      
end



      
